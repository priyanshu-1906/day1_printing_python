# Write your code below this 
name = input("what is your name ")
print(name)

